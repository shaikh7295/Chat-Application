// const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../model/usermodel'); 


const JWT_SECRET = '123456'; 

exports.UserLogin = async (req, res) => {
  try {
    const { username, password } = req.body;

    // 1. Find user by username
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // 2. Compare passwords
    // const isMatch = await bcrypt.compare(password, user.password);
    const isMatch = user.password ==  password
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid password' });
    }

    // 3. Generate JWT
    const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: '7d' });

    // 4. Update status to "online"
    user.status = 'online';
    await user.save();

    // 5. Send response
    res.status(200).json({
      message: 'Login successful',
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        status: user.status
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
};
